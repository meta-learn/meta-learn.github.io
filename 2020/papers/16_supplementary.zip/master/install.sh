conda install -c conda-forge opencv
conda install numpy scipy matplotlib
conda install -c conda-forge pbzip2
conda install pillow tqdm
