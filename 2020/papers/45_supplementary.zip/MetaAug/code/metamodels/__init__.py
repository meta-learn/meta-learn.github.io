from metamodels.classification_heads import R2D2Head, R2D2Head_Mixup

__all__ = ('R2D2Head', 'R2D2Head_Mixup') 

